//���ļ���s3_9\smain3_9.cpp
#include "sclass3_9_ furniture.h"
int main( )
{
	SofaBed sb( 50.5 );
	sb.SetWeight( 51.9 );
	sb.WatchTV( );
	sb.FoldOut( );
	sb.Sleep( );
	return 0;
}
