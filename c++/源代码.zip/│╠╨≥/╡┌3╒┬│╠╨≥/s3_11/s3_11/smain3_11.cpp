//���ļ���s3_11\smain3_11.cpp
#include "sclass3_11_ people.h"
int main( )
{	
	People p1( 1001,'F',2000, 11, 4 );
	p1.Print( );
	return 0;
}
