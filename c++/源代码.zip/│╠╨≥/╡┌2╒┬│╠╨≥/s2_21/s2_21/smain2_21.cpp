// �ļ�·����: s2_21\smain2_21.cpp
#include<iostream>
using namespace std;

void Print( const int& n );
int main( )
{
	int i=10;
	Print(i);
}
void Print( const int& n )
{
	cout<<n<<endl;
}
