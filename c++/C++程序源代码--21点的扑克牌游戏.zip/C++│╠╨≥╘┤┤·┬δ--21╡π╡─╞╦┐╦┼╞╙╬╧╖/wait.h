#include<time.h>
#include<stdio.h>
void wait(int milli)
{
	clock_t start;
	start=clock();
	while((clock()-start)<milli)
		;
}