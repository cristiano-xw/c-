

#include<iostream.h>
#include<stdlib.h>
#include<conio.h>
#include<time.h>

void pause()
//displays a message and waits for the user to hit a key
{
	cout<<"Press Any Key To Continue"<<endl;
	getch();
}

int getint(int l=0,int h=100)
{
	int ent;
	cout<<"Please Enter A Number Between"<<l<<" and "<<h<<endl;
	cin>>ent;
	while((ent<l)||(ent>h))
	{
		cout<<"Error"<<endl;
		cout<<"Value must be between"<<l<<" and "<<h<<endl;
		cin>>ent;
	}
    return(ent);
}
void sign()
//Display ISAAC SHAFFER
{
	cout<<"This Program Was Written By >o<"<<endl;
}

int random(int hi,int lo)
//This Program Finds A Random Number Between Hi And Low
{int ran;
 srand((unsigned)time(NULL));
 ran=rand()%(hi-(lo-1))+lo;
 return(ran);
}