//�ļ�·������s2_10\sclass2_10_cpoint.cpp 
#include "sclass2_10_cpoint.h"
CPoint::CPoint( float x1, float y1 )      
{
	x = x1;
	y = y1;
}
void CPoint::Move(float x1, float y1)
{       
    x=x1;
	y=y1;
}
